function clearTextareaOne(){document.getElementById('textarea-one').value = "";};
function clearTextareaTwo(){document.getElementById('textarea-two').value = "";};